import { Element } from '../utils';

export class Cell extends Element {
  constructor(textContent, props) {
    super('li', textContent, props);
  }

  setView(view) {
    this.element.dataset.view = view;
  }

  setEmpty() {
    this.setView('');
  }

  setCross() {
    this.setView('cross');
  }
}
