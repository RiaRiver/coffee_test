import { Element } from '../utils';
import { HintCell } from '../components';

export class Hints extends Element {
  hints = [];

  constructor(type, hints) {
    super('div', '', { class: `${type}-hints` });

    this.createHintsBlock(hints);
    this.render();
  }

  render() {
    this.hints.forEach((row) => {
      const hintsWrapper = new Element('ul', '', { class: 'cells-wrapper' });
      row.forEach((cell) => hintsWrapper.getElement().append(cell.getElement()));
      this.element.append(hintsWrapper.getElement());
    });
  }

  createHintsBlock(hints) {
    const size = Math.max(...hints.map((row) => row.length));
    let ind = 0;

    hints.forEach((row) => {
      const cells = [];

      for (let i = 0; i < size; i += 1) {
        const value = row[row.length - size + i] || '';
        const hintCell = new HintCell(ind, value);
        hintCell.setListeners([
          { event: 'click', handler: this.handleClick.bind(hintCell) },
          { event: 'contextmenu', handler: (event) => { event.preventDefault(); } }]);
        cells.push(hintCell);
        ind += 1;
      }

      this.hints.push(cells);
    });
  }

  handleClick(event) {
    event.preventDefault();
    const { target } = event;
    if (!target.textContent) return;

    if (target.dataset.view === 'cross') {
      this.setEmpty();
    } else this.setCross();
  }
}
