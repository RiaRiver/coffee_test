import { Element } from '../utils';
import { Field } from './field';
import { Hints } from './hints';

export class GameContainer extends Element {
  constructor(nonogram) {
    super('div', '', { class: 'game__container' });

    this.render(nonogram);
  }

  render(nonogram) {
    const field = new Field(nonogram.rows, nonogram.cols);
    const horizontalHints = new Hints('horizontal', nonogram.horizontalHints);
    const verticalHints = new Hints('vertical', nonogram.verticalHints);

    this.element.append(field.getElement(), horizontalHints.getElement(), verticalHints.getElement());
  }
}
