import { Element } from '../utils';
import { GameContainer } from '../widgets';
import { getNonogram } from '../nonogram';

export class MainPage extends Element {
  constructor() {
    super('main', '', { class: 'main' });

    this.render();
  }

  render() {
    const field = new GameContainer(getNonogram());

    this.element.append(field.getElement());
  }
}
